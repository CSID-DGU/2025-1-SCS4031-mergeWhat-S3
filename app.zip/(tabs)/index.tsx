// 시장 탭
import React, { useRef, useMemo } from 'react';
import { View, StyleSheet, Text } from 'react-native';

// BottomSheet 컴포넌트 불러오기
import BottomSheet from '@gorhom/bottom-sheet';

// 컴포넌트 불러오기
import SearchBar from '@/components/SearchBar'; // 검색창
import MapPlaceholder from '@/components/MapPlaceholder'; // 지도(카카오맵으로 대체)
import NearbyList from '@/components/NearbyList'; // 슬라이딩 영역 임시 리스트

export default function HomeScreen() {
  //BottomSheet 제어 참조 변수
  const bottomSheetRef = useRef<BottomSheet>(null);

  //슬라이딩 카드 비율 결정, 슬라이딩 필요 없을 시 제외
  const snapPoints = useMemo(() => ['50%'], []);

  return (
    <View style={styles.container}>
      {/* 지도 영역 */}
      <View style={styles.mapContainer}>
        <MapPlaceholder />
      </View>

      {/* 검색창, 지도 위에 표시 */}
      <View style={styles.searchBarContainer}>
        <SearchBar />
      </View>

      {/* 슬라이딩 부분 BottomSheet, 임시 리스트 포함 */}
      <BottomSheet
        ref={bottomSheetRef} // 참조 연결
        snapPoints={snapPoints}   // 슬라이딩 포인트 비율
        bottomInset={46}
        detached={true}
        style={styles.sheetContainer}
      >
        <View>
          <Text>이래도 안떠?</Text>
        </View>
      </BottomSheet>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  mapContainer: {
    flex: 1,
  },

  searchBarContainer: {
    position: 'absolute', // 지도 위에 검색창 겹침
    top: 40,
    left: 20,
    right: 20,
    zIndex: 10,
  },

  sheetContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    borderRadius: 20,
  },
});