// 커뮤니티 탭
import React from 'react';
import { View, StyleSheet, Text } from 'react-native';
import BottomSheet from '@gorhom/bottom-sheet';

const comm = () => {
    return (
        <View style={styles.container}>
            <Text>커뮤니티 탭입니다.</Text>
            <BottomSheet
                snapPoints={['30%']}
                backgroundStyle={{ backgroundColor: 'black' }}
            >
                <Text>슬라이딩 테스트</Text>
            </BottomSheet>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    }
});

export default comm;